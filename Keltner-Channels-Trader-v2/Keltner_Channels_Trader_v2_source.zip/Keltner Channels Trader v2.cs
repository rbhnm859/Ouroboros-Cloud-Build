using System;
using System.Linq;
using cAlgo.API;
using cAlgo.API.Indicators;

namespace cAlgo.Robots
{
    [Robot(TimeZone = TimeZones.UTC, AccessRights = AccessRights.None)]
    public class KeltnerChannelsTraderV2 : Robot
    {
        private KeltnerChannels _keltner;
        private AverageTrueRange _atr;

        [Parameter("Label", DefaultValue = "KeltnerTraderV2", Group = "General")]
        public string Label { get; set; }

        [Parameter("Enable Trading", DefaultValue = true, Group = "General")]
        public bool EnableTrading { get; set; }

        [Parameter("Volume (Lots)", DefaultValue = 0.01, MinValue = 0.01, Group = "Risk")]
        public double VolumeInLots { get; set; }

        [Parameter("Max Open Positions", DefaultValue = 1, MinValue = 1, Group = "Risk")]
        public int MaxOpenPositions { get; set; }

        [Parameter("Max Spread (pips)", DefaultValue = 3.0, MinValue = 0, Group = "Risk")]
        public double MaxSpreadPips { get; set; }

        [Parameter("MA Period", DefaultValue = 20, MinValue = 1, Group = "Keltner")]
        public int MAPeriod { get; set; }

        [Parameter("MA Type", DefaultValue = MovingAverageType.Exponential, Group = "Keltner")]
        public MovingAverageType MAType { get; set; }

        [Parameter("ATR Period", DefaultValue = 10, MinValue = 1, Group = "Keltner")]
        public int AtrPeriod { get; set; }

        [Parameter("ATR MA Type", DefaultValue = MovingAverageType.Exponential, Group = "Keltner")]
        public MovingAverageType AtrMAType { get; set; }

        [Parameter("Band Distance", DefaultValue = 2.0, MinValue = 0.1, Group = "Keltner")]
        public double BandDistance { get; set; }

        [Parameter("Use ATR SL/TP", DefaultValue = true, Group = "Stops")]
        public bool UseAtrStops { get; set; }

        [Parameter("Fixed SL (pips)", DefaultValue = 20.0, MinValue = 0.1, Group = "Stops")]
        public double FixedStopLossPips { get; set; }

        [Parameter("Fixed TP (pips)", DefaultValue = 30.0, MinValue = 0.1, Group = "Stops")]
        public double FixedTakeProfitPips { get; set; }

        [Parameter("ATR SL Multiplier", DefaultValue = 1.5, MinValue = 0.1, Group = "Stops")]
        public double AtrStopMultiplier { get; set; }

        [Parameter("ATR TP Multiplier", DefaultValue = 2.25, MinValue = 0.1, Group = "Stops")]
        public double AtrTakeProfitMultiplier { get; set; }

        [Parameter("Enable Breakeven", DefaultValue = true, Group = "Management")]
        public bool EnableBreakeven { get; set; }

        [Parameter("BE Trigger (R)", DefaultValue = 1.0, MinValue = 0.1, Group = "Management")]
        public double BreakevenTriggerR { get; set; }

        [Parameter("BE Extra (pips)", DefaultValue = 0.2, MinValue = 0.0, Group = "Management")]
        public double BreakevenExtraPips { get; set; }

        [Parameter("Enable ATR Trailing", DefaultValue = false, Group = "Management")]
        public bool EnableAtrTrailing { get; set; }

        [Parameter("ATR Trail Multiplier", DefaultValue = 1.2, MinValue = 0.1, Group = "Management")]
        public double AtrTrailMultiplier { get; set; }

        protected override void OnStart()
        {
            _keltner = Indicators.KeltnerChannels(
                MAPeriod,
                MAType,
                AtrPeriod,
                AtrMAType,
                BandDistance);

            _atr = Indicators.AverageTrueRange(AtrPeriod, MovingAverageType.Exponential);
        }

        protected override void OnBarClosed()
        {
            if (!EnableTrading || Bars.Count < Math.Max(MAPeriod, AtrPeriod) + 5)
                return;

            if (GetSpreadPips() > MaxSpreadPips)
                return;

            var close0 = Bars.ClosePrices.Last(0);
            var close1 = Bars.ClosePrices.Last(1);
            var top0 = _keltner.Top.Last(0);
            var top1 = _keltner.Top.Last(1);
            var bottom0 = _keltner.Bottom.Last(0);
            var bottom1 = _keltner.Bottom.Last(1);

            bool bullishBreakout = close0 > top0 && close1 <= top1;
            bool bearishBreakout = close0 < bottom0 && close1 >= bottom1;

            if (bullishBreakout)
                TryOpen(TradeType.Buy);
            else if (bearishBreakout)
                TryOpen(TradeType.Sell);
        }

        protected override void OnTick()
        {
            ManagePositions();
        }

        private void TryOpen(TradeType tradeType)
        {
            var positions = Positions.FindAll(Label, SymbolName);

            if (positions.Length >= MaxOpenPositions)
                return;

            foreach (var p in positions.Where(p => p.TradeType != tradeType).ToArray())
                ClosePosition(p);

            if (Positions.FindAll(Label, SymbolName).Length >= MaxOpenPositions)
                return;

            double stopLossPips;
            double takeProfitPips;

            if (UseAtrStops)
            {
                var atrPips = _atr.Result.LastValue / Symbol.PipSize;
                if (double.IsNaN(atrPips) || atrPips <= 0)
                    return;

                stopLossPips = Math.Max(atrPips * AtrStopMultiplier, GetSpreadPips() * 2.0);
                takeProfitPips = Math.Max(atrPips * AtrTakeProfitMultiplier, stopLossPips);
            }
            else
            {
                stopLossPips = FixedStopLossPips;
                takeProfitPips = FixedTakeProfitPips;
            }

            var volume = Symbol.QuantityToVolumeInUnits(VolumeInLots);
            volume = Symbol.NormalizeVolumeInUnits(volume, RoundingMode.Down);

            if (volume < Symbol.VolumeInUnitsMin)
                volume = Symbol.VolumeInUnitsMin;

            ExecuteMarketOrder(
                tradeType,
                SymbolName,
                volume,
                Label,
                stopLossPips,
                takeProfitPips);
        }

        private void ManagePositions()
        {
            var atrPips = _atr.Result.LastValue / Symbol.PipSize;

            foreach (var position in Positions.FindAll(Label, SymbolName))
            {
                if (!position.StopLoss.HasValue)
                    continue;

                var riskPips = Math.Abs(position.EntryPrice - position.StopLoss.Value) / Symbol.PipSize;
                if (riskPips <= 0)
                    continue;

                if (EnableBreakeven && position.Pips >= riskPips * BreakevenTriggerR)
                {
                    double bePrice = position.TradeType == TradeType.Buy
                        ? position.EntryPrice + BreakevenExtraPips * Symbol.PipSize
                        : position.EntryPrice - BreakevenExtraPips * Symbol.PipSize;

                    if (IsBetterStop(position, bePrice))
                        ModifyPosition(position, bePrice, position.TakeProfit);
                }

                if (EnableAtrTrailing && atrPips > 0)
                {
                    double distance = atrPips * AtrTrailMultiplier * Symbol.PipSize;
                    double trailPrice = position.TradeType == TradeType.Buy
                        ? Symbol.Bid - distance
                        : Symbol.Ask + distance;

                    if (IsBetterStop(position, trailPrice))
                        ModifyPosition(position, trailPrice, position.TakeProfit);
                }
            }
        }

        private bool IsBetterStop(Position position, double proposedStop)
        {
            if (position.TradeType == TradeType.Buy)
            {
                if (proposedStop >= Symbol.Bid)
                    return false;
                return !position.StopLoss.HasValue || proposedStop > position.StopLoss.Value;
            }

            if (proposedStop <= Symbol.Ask)
                return false;
            return !position.StopLoss.HasValue || proposedStop < position.StopLoss.Value;
        }

        private double GetSpreadPips()
        {
            return (Symbol.Ask - Symbol.Bid) / Symbol.PipSize;
        }
    }
}
