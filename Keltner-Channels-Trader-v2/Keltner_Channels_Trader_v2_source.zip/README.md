# Keltner Channels Trader v2

基底：Spotware 官方 Keltner Channels Sample。

## 核心
- Keltner 上軌收盤突破 -> Buy
- Keltner 下軌收盤跌破 -> Sell
- 非 Grid
- 非 Martingale
- Max Open Positions
- Spread Filter
- ATR 或 Fixed SL/TP
- Breakeven
- Optional ATR Trailing

## 預設測試
M1 / M5 / M15 / H1 都可掛載，但先建議 M5、M15 做 baseline。

## 市場
Forex 任意貨幣對、XAUUSD、BTC/ETH/SOL 等皆可測；實際 Symbol 名稱依券商而定。

## Build
專案目標：
- net6.0
- cTrader.Automate

最穩定方式：
cTrader Windows -> Algo -> 建立 cBot -> 貼入 .cs -> Build -> 產生 .algo。

此 ZIP 為 source package；目前聊天執行環境沒有 .NET SDK，因此尚未在此環境完成實際 cTrader Build 驗證。
