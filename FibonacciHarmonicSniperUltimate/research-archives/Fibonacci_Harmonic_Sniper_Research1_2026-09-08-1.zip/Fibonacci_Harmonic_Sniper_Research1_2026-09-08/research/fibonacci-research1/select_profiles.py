#!/usr/bin/env python3
"""Select one development profile per symbol without looking at holdout data."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


def find_key(obj, wanted: str):
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key.lower() == wanted.lower():
                return value
            found = find_key(value, wanted)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for value in obj:
            found = find_key(value, wanted)
            if found is not None:
                return found
    return None


def load_report(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    main = data["main"]
    stats = data["tradeStatistics"]

    trades = int(stats["totalTrades"]["all"])
    wins = int(stats["winningTrades"]["all"])
    net = float(main["netProfit"])
    roi = float(main.get("roi", 0.0))
    drawdown = float(data["equity"]["maxEquityDrawdownPercent"])

    raw_profit_factor = find_key(data, "profitFactor")
    try:
        profit_factor = (
            float(raw_profit_factor) if raw_profit_factor is not None else None
        )
    except (TypeError, ValueError):
        profit_factor = None

    return {
        "trades": trades,
        "wins": wins,
        "net": net,
        "roi": roi,
        "dd": drawdown,
        "profit_factor": profit_factor,
    }


def profile_score(metrics: dict) -> float:
    profit_factor_bonus = 0.0
    profit_factor = metrics["profit_factor"]
    if profit_factor is not None and math.isfinite(profit_factor):
        profit_factor_bonus = min(profit_factor, 3.0) * 2.0

    return metrics["roi"] - 0.75 * metrics["dd"] + profit_factor_bonus


def passes_development(metrics: dict) -> bool:
    if metrics["trades"] < 20:
        return False
    if metrics["net"] <= 0:
        return False
    if metrics["dd"] > 15.0:
        return False

    profit_factor = metrics["profit_factor"]
    if (
        profit_factor is not None
        and math.isfinite(profit_factor)
        and profit_factor < 1.10
    ):
        return False

    return True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reports-dir", type=Path, required=True)
    parser.add_argument("--eurusd-spread", default="1.0")
    parser.add_argument("--xauusd-spread", default="25.0")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    candidates: dict[str, list[tuple[str, dict]]] = {
        "EURUSD": [],
        "XAUUSD": [],
    }

    for path in sorted(args.reports_dir.rglob("*.json")):
        matched_symbol = next(
            (
                symbol
                for symbol in candidates
                if path.stem.endswith(f"-{symbol}")
            ),
            None,
        )
        if matched_symbol is None:
            continue

        profile = path.stem[: -(len(matched_symbol) + 1)]
        metrics = load_report(path)
        metrics["score"] = profile_score(metrics)
        metrics["development_pass"] = passes_development(metrics)
        candidates[matched_symbol].append((profile, metrics))

    spreads = {
        "EURUSD": args.eurusd_spread,
        "XAUUSD": args.xauusd_spread,
    }
    selection = {}
    matrix_include = []

    for symbol, rows in candidates.items():
        eligible = [
            (name, metrics)
            for name, metrics in rows
            if metrics["development_pass"]
        ]
        eligible.sort(key=lambda item: item[1]["score"], reverse=True)

        if eligible:
            profile, metrics = eligible[0]
            selection[symbol] = {
                "profile": profile,
                "metrics": metrics,
            }
            matrix_include.append(
                {
                    "symbol": symbol,
                    "profile": profile,
                    "spread": spreads[symbol],
                }
            )
        else:
            selection[symbol] = {
                "profile": None,
                "metrics": None,
            }

    result = {
        "selection": selection,
        "matrix": {"include": matrix_include},
    }
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
