#!/usr/bin/env python3
"""Evaluate untouched holdout reports against predefined research gates."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


def find_key(obj, wanted: str):
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key.lower() == wanted.lower():
                return value
            found = find_key(value, wanted)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for value in obj:
            found = find_key(value, wanted)
            if found is not None:
                return found
    return None


def extract_metrics(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    main = data["main"]
    stats = data["tradeStatistics"]

    trades = int(stats["totalTrades"]["all"])
    wins = int(stats["winningTrades"]["all"])
    net = float(main["netProfit"])
    roi = float(main.get("roi", 0.0))
    drawdown = float(data["equity"]["maxEquityDrawdownPercent"])

    raw_profit_factor = find_key(data, "profitFactor")
    try:
        profit_factor = (
            float(raw_profit_factor) if raw_profit_factor is not None else None
        )
    except (TypeError, ValueError):
        profit_factor = None

    passed = trades >= 8 and net > 0 and drawdown <= 12.0
    if (
        profit_factor is not None
        and math.isfinite(profit_factor)
    ):
        passed = passed and profit_factor >= 1.10

    return {
        "trades": trades,
        "wins": wins,
        "win_rate": (100.0 * wins / trades) if trades else None,
        "net": net,
        "roi": roi,
        "max_equity_dd_percent": drawdown,
        "profit_factor": profit_factor,
        "holdout_pass": passed,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reports-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    results = {}
    for path in sorted(args.reports_dir.rglob("*.json")):
        symbol = None
        if "EURUSD" in path.stem:
            symbol = "EURUSD"
        elif "XAUUSD" in path.stem:
            symbol = "XAUUSD"

        if symbol is not None:
            results[symbol] = extract_metrics(path)

    research_pass = bool(results) and all(
        metrics["holdout_pass"] for metrics in results.values()
    )
    result = {
        "status": "RESEARCH_PASS" if research_pass else "NOT_APPROVED",
        "symbols": results,
        "note": (
            "RESEARCH_PASS means the predefined historical holdout gates passed. "
            "It does not guarantee future or live profitability."
        ),
    }

    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if research_pass else 2


if __name__ == "__main__":
    raise SystemExit(main())
