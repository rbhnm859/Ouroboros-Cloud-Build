# Fibonacci Harmonic Sniper Ultimate — v0.4.0-research1

This pack keeps `Fibonacci-v0.3.0-fix3` immutable.

## Research hypotheses

1. If D completes inside XA, the structural invalidation anchor is X; extension patterns keep D as the anchor.
2. If the harmonic target does not satisfy `MinimumRiskReward`, reject the trade instead of silently replacing the target with a farther arbitrary R:R target.
3. Test smaller entry distance / pattern age values to avoid chasing a reversal too far after D is confirmed.
4. Keep Fibonacci/Harmonic as the primary signal. EMA/ATR/candles remain confirmation or risk controls only.
5. No Grid, Martingale, or loss-multiplying logic.

## Windows

- Development: 2024-01-01 through 2025-12-31.
- Untouched holdout: 2026-01-01 through 2026-09-08.
- Research balance: USD 10,000.
- Risk: 1% equity.
- Broker commission: `--commission-auto`.
- Spread: explicit workflow input.

The larger research balance isolates strategy edge from the known USD 200 / XAUUSD minimum-volume feasibility constraint. It does not mean USD 10,000 is required for deployment.

## Development gates

Per symbol:

- at least 20 trades;
- positive net profit;
- max equity drawdown <= 15%;
- profit factor >= 1.10 when that metric is present in the report JSON.

## Holdout gates

Per selected symbol:

- at least 8 trades;
- positive net profit;
- max equity drawdown <= 12%;
- profit factor >= 1.10 when present.

Passing these gates is historical research evidence, not a guarantee of live profit.

## Install

Copy this pack's `tools/`, `research/`, and `.github/workflows/` paths into the root of:

`rbhnm859/Ouroboros-Cloud-Build`

Then run the workflow:

`Fibonacci research1 finite walk-forward`

The workflow creates `Fibonacci-v0.4.0-research1` from `Fibonacci-v0.3.0-fix3` at runtime.

## Deployment gate after research pass

Run a separate feasibility test with the actual intended account balance and actual FxPro symbol specifications. If the minimum tradable XAUUSD volume exceeds the 1% risk budget, mark that symbol/account combination as not deployable rather than increasing risk to force entries.
