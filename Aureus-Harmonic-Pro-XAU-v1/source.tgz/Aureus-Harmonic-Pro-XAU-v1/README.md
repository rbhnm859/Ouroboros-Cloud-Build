# Aureus Harmonic Pro XAU v1

Commercial-oriented XAUUSD cBot for cTrader, rebuilt from scratch from the harmonic/Fibonacci research specification.

## Core design

- Harmonic-only entries: Gartley, Bat, Alternate Bat, Butterfly, Crab, Deep Crab, Cypher, Shark, AB=CD.
- Confirmed-pivot logic to reduce ZigZag repaint/look-ahead risk.
- M15 execution trigger + H1/H4 harmonic conflict/confluence filter.
- DST-aware London open to New York close entry window.
- Strict single-symbol exposure: no duplicate entry and no hedging.
- Equity-risk position sizing with broker min/max normalization and estimated-margin reserve checks.
- Daily/weekly/peak-equity circuit breakers, consecutive-loss block and cooldown.
- Spread/gap/volatility/slippage guards.
- Harmonic invalidation stop, harmonic CD retracement target, minimum R:R gate.
- Break-even + trailing management.
- cTrader LocalStorage restart recovery under AccessRights.None.

## Platform

C# / cTrader Automate, target net6.0. Build with the cTrader.Automate NuGet package. The generated `.algo` can be uploaded/launched through cTrader's supported app/cloud flow; development and backtesting are performed on cTrader Windows/Mac.

## Important

This repository does not claim guaranteed profit or a guaranteed monthly compound return. The bot must pass the validation plan on the exact FxPro XAUUSD symbol/account conditions before a commercial release claim is made.
