# Commercial v1 XAUUSD preset

Baseline is deliberately conservative and must be validated on the target FxPro account before live use.

- Timeframe attached: M15
- Symbol: XAUUSD (aliases supported: XAUUSD, GOLD)
- Risk per trade: 0.75% equity
- Minimum harmonic score: 82
- Ratio tolerance: 4%
- Multi-timeframe consensus: 76; H4 veto: 82
- London local open: 08:00 + 5 minute delay
- New York local close: 17:00 - 15 minute buffer; Friday cutoff 16:00 NY
- Minimum reward:risk: 3.0
- Daily equity loss circuit: 2.5%
- Weekly equity loss circuit: 5.0%
- Peak equity drawdown circuit: 10.0%
- Consecutive loss circuit: 3
- Cooldown: 4 x M15 bars
- No Grid / Martingale / DCA / Recovery / loss averaging / hedging
- Max simultaneous XAU exposure: one position or pending order across the account
