# Commercial validation plan

Do not market or price this cBot on hypothetical performance. Compile first, then run the exact FxPro XAUUSD history in cTrader.

## Required windows

- Recent 1 month: execution sanity and current-regime check.
- Recent 1 year: primary development / robustness evidence.
- Recent 3 years: regime coverage across trend, range and volatility shocks.

## Required tests

- Tick-data backtest where available; include real spread/commission/swap assumptions.
- In-sample / out-of-sample split with no parameter tuning on OOS.
- Walk-forward windows.
- Parameter sensitivity around pivot depths, ratio tolerance, score threshold and stop buffer.
- Monte Carlo trade-order reshuffling and cost/slippage stress.
- One-at-a-time spread +25%, +50% and slippage stress.

## Commercial go/no-go gates (targets, not guarantees)

- Profit Factor: target >= 1.7; preferred >= 2.0 OOS.
- Max equity drawdown: target <= 12%; preferred <= 10%.
- Recovery factor: >= 2.0.
- Positive expectancy after costs.
- Minimum R:R gate is configured at 3.0, but realized average R must be measured after BE/trailing.
- OOS remains profitable and does not collapse under modest parameter perturbation.
- Three-year sample contains enough trades to rule out a result driven by a handful of outliers.
- No duplicate positions, no opposite-direction hedge, no missing SL/TP in execution logs.

There is no honest method to guarantee a monthly return, future Profit Factor, or one-pass profitability. Release is permitted only if the measured validation meets the acceptance gates.
