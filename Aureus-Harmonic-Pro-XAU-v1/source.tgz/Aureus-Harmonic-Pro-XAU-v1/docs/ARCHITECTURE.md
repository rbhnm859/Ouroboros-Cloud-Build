# Aureus Harmonic Pro XAU v1 architecture

This is a clean-room commercial-v1 implementation created from the research specification, not a modification of the earlier FibonacciHarmonicSniperUltimate strategy.

## Signal pipeline

1. Load XAUUSD M15/H1/H4 bars.
2. Detect only confirmed, non-repainting swing pivots (a pivot requires right-side confirmation bars).
3. Validate harmonic geometry and Fibonacci ratios for Gartley, Bat, Alternate Bat, Butterfly, Crab, Deep Crab, Cypher, Shark and AB=CD.
4. Build a stable Pattern ID from pattern type, direction, timeframe and pivot timestamps.
5. Require an M15 harmonic trigger. H1/H4 harmonic patterns are used strictly as confluence/conflict filters; they cannot create a standalone entry.
6. Reject strong opposite H4 patterns; score H1/H4 agreement.
7. Require London-open to New-York-close session using DST-aware London and New York time zones.
8. Apply spread, gap, abnormal volatility, daily/weekly loss, peak drawdown, consecutive-loss, cooldown and margin-reserve guards.
9. Place one market position only if the harmonic target supports the configured minimum R:R.
10. Manage the trade using protected break-even and trailing logic.

## Anti-duplicate / anti-hedge

- In-process entry lock prevents two order paths from firing concurrently.
- Any existing position on the current XAU symbol blocks a new entry, regardless of label or direction.
- Any existing pending order on the current XAU symbol blocks a new entry.
- Pattern IDs are claimed before order submission and persisted through cTrader LocalStorage.
- LocalStorage uses AccessRights.None and restores pattern/risk state after restart.
- A second independent cBot instance can never be made mathematically atomic solely with account-side cBot APIs; commercial deployment should run one Aureus instance per XAU account. The account-wide position/order block is the final line of defence.

## Risk model

No user-defined fixed maximum-lot cap is required. Volume is derived from equity risk and stop distance using Symbol.VolumeForProportionalRisk, normalized to broker limits and capped by Symbol.VolumeInUnitsMax. The order is rejected if broker minimum size would exceed risk or if estimated margin would violate free-margin reserves.

## Harmonic-only entry guarantee

No EMA, RSI, MACD, breakout or non-harmonic signal can open a trade. Market/session/volatility components are veto filters only. A qualified M15 harmonic PatternCandidate is mandatory for every entry.
