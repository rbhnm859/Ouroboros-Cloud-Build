using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using cAlgo.API;
using cAlgo.Robots.AureusHarmonic;

namespace cAlgo.Robots
{
    [Robot(Name = "Aureus Harmonic Pro XAU", TimeZone = TimeZones.UTC, AccessRights = AccessRights.None, DefaultSymbolName = "XAUUSD", DefaultTimeFrame = "M15")]
    public class AureusHarmonicProXAU : Robot
    {
        [Parameter("Trading Enabled", Group = "General", DefaultValue = true)]
        public bool TradingEnabled { get; set; }

        [Parameter("Bot Label", Group = "General", DefaultValue = "AHP_XAU_V1")]
        public string BotLabel { get; set; }

        [Parameter("Gold Symbol Aliases", Group = "General", DefaultValue = "XAUUSD,GOLD")]
        public string GoldSymbolAliases { get; set; }

        [Parameter("Debug Logging", Group = "General", DefaultValue = false)]
        public bool DebugLogging { get; set; }

        [Parameter("Ratio Tolerance %", Group = "Harmonic", DefaultValue = 4.0, MinValue = 0.5, MaxValue = 12.0, Step = 0.5)]
        public double RatioTolerancePercent { get; set; }

        [Parameter("Minimum Pattern Score", Group = "Harmonic", DefaultValue = 82.0, MinValue = 60.0, MaxValue = 99.0, Step = 1.0)]
        public double MinimumPatternScore { get; set; }

        [Parameter("M15 Pivot Depth", Group = "Harmonic", DefaultValue = 5, MinValue = 2, MaxValue = 15)]
        public int M15PivotDepth { get; set; }

        [Parameter("H1 Pivot Depth", Group = "Harmonic", DefaultValue = 4, MinValue = 2, MaxValue = 15)]
        public int H1PivotDepth { get; set; }

        [Parameter("H4 Pivot Depth", Group = "Harmonic", DefaultValue = 3, MinValue = 2, MaxValue = 12)]
        public int H4PivotDepth { get; set; }

        [Parameter("Max Entry Distance %XA", Group = "Harmonic", DefaultValue = 8.0, MinValue = 1.0, MaxValue = 30.0, Step = 0.5)]
        public double MaxEntryDistancePctOfXa { get; set; }

        [Parameter("Minimum Consensus Score", Group = "MTF", DefaultValue = 76.0, MinValue = 50.0, MaxValue = 99.0)]
        public double MinimumConsensusScore { get; set; }

        [Parameter("H4 Conflict Veto Score", Group = "MTF", DefaultValue = 82.0, MinValue = 60.0, MaxValue = 99.0)]
        public double H4ConflictVetoScore { get; set; }

        [Parameter("Require H1/H4 Support", Group = "MTF", DefaultValue = true)]
        public bool RequireHigherTimeframeSupport { get; set; }

        [Parameter("London Open Hour", Group = "Session", DefaultValue = 8, MinValue = 0, MaxValue = 23)]
        public int LondonOpenHour { get; set; }

        [Parameter("London Open Delay Min", Group = "Session", DefaultValue = 5, MinValue = 0, MaxValue = 60)]
        public int LondonOpenDelayMinutes { get; set; }

        [Parameter("New York Close Hour", Group = "Session", DefaultValue = 17, MinValue = 0, MaxValue = 23)]
        public int NewYorkCloseHour { get; set; }

        [Parameter("NY Close Buffer Min", Group = "Session", DefaultValue = 15, MinValue = 0, MaxValue = 120)]
        public int NewYorkCloseBufferMinutes { get; set; }

        [Parameter("Friday Cutoff NY Hour", Group = "Session", DefaultValue = 16, MinValue = 12, MaxValue = 23)]
        public int FridayCutoffNyHour { get; set; }

        [Parameter("Risk per Trade %", Group = "Risk", DefaultValue = 0.75, MinValue = 0.10, MaxValue = 3.00, Step = 0.05)]
        public double RiskPerTradePercent { get; set; }

        [Parameter("Max Daily Equity Loss %", Group = "Risk", DefaultValue = 2.5, MinValue = 0.5, MaxValue = 10.0, Step = 0.5)]
        public double MaxDailyLossPercent { get; set; }

        [Parameter("Max Weekly Equity Loss %", Group = "Risk", DefaultValue = 5.0, MinValue = 1.0, MaxValue = 20.0, Step = 0.5)]
        public double MaxWeeklyLossPercent { get; set; }

        [Parameter("Max Peak Equity DD %", Group = "Risk", DefaultValue = 10.0, MinValue = 2.0, MaxValue = 30.0, Step = 0.5)]
        public double MaxPeakDrawdownPercent { get; set; }

        [Parameter("Max Consecutive Losses", Group = "Risk", DefaultValue = 3, MinValue = 1, MaxValue = 10)]
        public int MaxConsecutiveLosses { get; set; }

        [Parameter("Cooldown M15 Bars", Group = "Risk", DefaultValue = 4, MinValue = 0, MaxValue = 32)]
        public int CooldownM15Bars { get; set; }

        [Parameter("Stop Buffer %XA", Group = "Risk", DefaultValue = 3.0, MinValue = 0.5, MaxValue = 15.0, Step = 0.5)]
        public double StopBufferPctOfXa { get; set; }

        [Parameter("Min Stop Buffer Pips", Group = "Risk", DefaultValue = 25.0, MinValue = 1.0, MaxValue = 500.0)]
        public double MinStopBufferPips { get; set; }

        [Parameter("Target Retracement of CD", Group = "Risk", DefaultValue = 0.618, MinValue = 0.382, MaxValue = 1.0, Step = 0.01)]
        public double TargetRetracementOfCd { get; set; }

        [Parameter("Minimum Reward:Risk", Group = "Risk", DefaultValue = 3.0, MinValue = 1.0, MaxValue = 8.0, Step = 0.25)]
        public double MinimumRewardRisk { get; set; }

        [Parameter("Max New Margin Share %", Group = "Risk", DefaultValue = 25.0, MinValue = 5.0, MaxValue = 80.0)]
        public double MaxNewTradeMarginSharePct { get; set; }

        [Parameter("Min Free Margin After %Eq", Group = "Risk", DefaultValue = 60.0, MinValue = 10.0, MaxValue = 95.0)]
        public double MinFreeMarginAfterPct { get; set; }

        [Parameter("Max Spread Pips", Group = "Market Guards", DefaultValue = 80.0, MinValue = 1.0, MaxValue = 1000.0)]
        public double MaxSpreadPips { get; set; }

        [Parameter("Max Gap Pips", Group = "Market Guards", DefaultValue = 180.0, MinValue = 10.0, MaxValue = 3000.0)]
        public double MaxGapPips { get; set; }

        [Parameter("Max Bar/Median Range", Group = "Market Guards", DefaultValue = 3.5, MinValue = 1.2, MaxValue = 10.0, Step = 0.1)]
        public double MaxBarRangeMultiple { get; set; }

        [Parameter("Max Entry Slippage Pips", Group = "Market Guards", DefaultValue = 50.0, MinValue = 1.0, MaxValue = 500.0)]
        public double MaxEntrySlippagePips { get; set; }

        [Parameter("Breakeven Start R", Group = "Trade Management", DefaultValue = 1.25, MinValue = 0.5, MaxValue = 4.0, Step = 0.05)]
        public double BreakevenStartR { get; set; }

        [Parameter("Breakeven Lock R", Group = "Trade Management", DefaultValue = 0.10, MinValue = 0.0, MaxValue = 1.0, Step = 0.05)]
        public double BreakevenLockR { get; set; }

        [Parameter("Trailing Start R", Group = "Trade Management", DefaultValue = 2.0, MinValue = 0.75, MaxValue = 6.0, Step = 0.25)]
        public double TrailingStartR { get; set; }

        [Parameter("Trailing Distance R", Group = "Trade Management", DefaultValue = 1.0, MinValue = 0.25, MaxValue = 3.0, Step = 0.25)]
        public double TrailingDistanceR { get; set; }

        private Bars _m15;
        private Bars _h1;
        private Bars _h4;
        private HarmonicPatternDetector _detector;
        private MultiTimeframeConsensus _consensus;
        private SessionFilter _session;
        private RiskEngine _risk;
        private DateTime _lastM15OpenTime;
        private bool _entryInFlight;
        private HashSet<string> _usedPatternIds;
        private List<string> _usedPatternOrder;

        private double _peakEquity;
        private double _dayStartEquity;
        private double _weekStartEquity;
        private DateTime _dayKey;
        private DateTime _weekKey;
        private int _consecutiveLosses;
        private DateTime _lastTradeCloseUtc;
        private bool _emergencyLock;

        protected override void OnStart()
        {
            if (!IsGoldSymbol(SymbolName))
            {
                Print("AHP BLOCK: symbol {0} is not in configured gold aliases ({1}).", SymbolName, GoldSymbolAliases);
                Stop();
                return;
            }

            _m15 = MarketData.GetBars(TimeFrame.Minute15, SymbolName);
            _h1 = MarketData.GetBars(TimeFrame.Hour, SymbolName);
            _h4 = MarketData.GetBars(TimeFrame.Hour4, SymbolName);
            EnsureHistory(_m15, 700);
            EnsureHistory(_h1, 550);
            EnsureHistory(_h4, 450);

            _detector = new HarmonicPatternDetector(RatioTolerancePercent / 100.0);
            _consensus = new MultiTimeframeConsensus();
            _session = new SessionFilter();
            _risk = new RiskEngine(this, Symbol);
            _usedPatternIds = LoadPatternRegistry();
            LoadRiskState();

            Positions.Closed += OnPositionClosed;
            _lastM15OpenTime = _m15.Count > 0 ? _m15.OpenTimes[_m15.Count - 1] : DateTime.MinValue;

            Print("Aureus Harmonic Pro XAU v1 started | Symbol={0} | Equity={1:F2} | Risk={2:F2}% | MinRR={3:F2}",
                SymbolName, Account.Equity, RiskPerTradePercent, MinimumRewardRisk);
        }

        protected override void OnTick()
        {
            RefreshRiskState();
            ManageOpenPosition();

            if (CheckEmergencyCircuit())
                return;

            if (_m15 == null || _m15.Count < 10)
                return;

            DateTime currentOpen = _m15.OpenTimes[_m15.Count - 1];
            if (currentOpen == _lastM15OpenTime)
                return;

            _lastM15OpenTime = currentOpen;
            EvaluateNewM15Bar();
        }

        protected override void OnException(Exception exception)
        {
            Print("AHP EXCEPTION: {0}", exception);
        }

        private void EvaluateNewM15Bar()
        {
            if (!TradingEnabled || _emergencyLock || _entryInFlight)
                return;

            if (!_session.IsTradingWindow(Server.Time, LondonOpenHour, LondonOpenDelayMinutes, NewYorkCloseHour, NewYorkCloseBufferMinutes, FridayCutoffNyHour))
            {
                Debug("BLOCK session");
                return;
            }

            string riskBlock;
            if (!RiskLimitsAllowEntry(out riskBlock))
            {
                Debug("BLOCK " + riskBlock);
                return;
            }

            if (HasAnyXauExposure())
            {
                Debug("BLOCK existing position/pending order on symbol");
                return;
            }

            string marketReason;
            if (!_risk.MarketSafetyPasses(_m15, MaxSpreadPips, MaxGapPips, MaxBarRangeMultiple, out marketReason))
            {
                Debug("BLOCK " + marketReason);
                return;
            }

            PatternCandidate m15 = _detector.GetBestPattern(_m15, M15PivotDepth, 650, 12, "M15");
            PatternCandidate h1 = _detector.GetBestPattern(_h1, H1PivotDepth, 500, 10, "H1");
            PatternCandidate h4 = _detector.GetBestPattern(_h4, H4PivotDepth, 400, 6, "H4");

            if (m15 == null || m15.Score < MinimumPatternScore)
            {
                Debug("BLOCK no qualified M15 harmonic pattern");
                return;
            }

            if (_usedPatternIds.Contains(m15.PatternId))
            {
                Debug("BLOCK duplicate PatternID=" + m15.PatternId);
                return;
            }

            double current = m15.Direction == SignalDirection.Buy ? Symbol.Ask : Symbol.Bid;
            double distanceFromD = Math.Abs(current - m15.D.Price);
            if (distanceFromD > m15.XaLength * (MaxEntryDistancePctOfXa / 100.0))
            {
                Debug("BLOCK entry too far from D/PRZ");
                return;
            }

            ConsensusResult consensus = _consensus.Evaluate(m15, h1, h4, MinimumConsensusScore, H4ConflictVetoScore, RequireHigherTimeframeSupport);
            if (!consensus.Accepted)
            {
                Debug("BLOCK MTF " + consensus.Reason);
                return;
            }

            string planReason;
            TradePlan plan = _risk.BuildTradePlan(m15, RiskPerTradePercent, StopBufferPctOfXa / 100.0, MinStopBufferPips,
                TargetRetracementOfCd, MinimumRewardRisk, MaxNewTradeMarginSharePct, MinFreeMarginAfterPct, out planReason);
            if (plan == null)
            {
                Debug("BLOCK risk plan: " + planReason);
                return;
            }

            ExecutePlan(m15, consensus, plan);
        }

        private void ExecutePlan(PatternCandidate pattern, ConsensusResult consensus, TradePlan plan)
        {
            _entryInFlight = true;
            ClaimPattern(pattern.PatternId);
            double expectedPrice = plan.Direction == SignalDirection.Buy ? Symbol.Ask : Symbol.Bid;
            string comment = string.Format(CultureInfo.InvariantCulture, "AHP;PID={0};R={1:F1};CS={2:F0};P={3}",
                pattern.PatternId, plan.StopLossPips, consensus.Score, pattern.Kind);

            try
            {
                TradeType side = plan.Direction == SignalDirection.Buy ? TradeType.Buy : TradeType.Sell;
                var result = ExecuteMarketOrder(side, SymbolName, plan.VolumeInUnits, BotLabel, plan.StopLossPips, plan.TakeProfitPips, comment);
                if (!result.IsSuccessful || result.Position == null)
                {
                    Print("AHP ORDER FAILED | Pattern={0} {1} | Error={2}", pattern.Kind, pattern.PatternId, result.Error);
                    return;
                }

                double slippagePips = Math.Abs(result.Position.EntryPrice - expectedPrice) / Symbol.PipSize;
                if (slippagePips > MaxEntrySlippagePips)
                {
                    Print("AHP SLIPPAGE CIRCUIT | PID={0} slip={1:F1}p > {2:F1}p. Closing.", result.Position.Id, slippagePips, MaxEntrySlippagePips);
                    ClosePosition(result.Position);
                    return;
                }

                Print("AHP OPEN | PID={0} | Pattern={1}/{2} | Side={3} | Score={4:F1} | Consensus={5:F1} | RR={6:F2} | Vol={7} | SL={8:F1}p | TP={9:F1}p | Margin~{10:F2}",
                    result.Position.Id, pattern.TimeFrameName, pattern.Kind, plan.Direction, pattern.Score, consensus.Score,
                    plan.RewardRisk, plan.VolumeInUnits, plan.StopLossPips, plan.TakeProfitPips, plan.EstimatedMargin);
            }
            finally
            {
                _entryInFlight = false;
            }
        }

        private void ManageOpenPosition()
        {
            var positions = Positions.FindAll(BotLabel, SymbolName);
            foreach (var p in positions)
            {
                double initialRiskPips = ParseInitialRiskPips(p.Comment);
                if (initialRiskPips <= 0)
                    continue;

                if (p.Pips >= initialRiskPips * BreakevenStartR)
                {
                    double lockPips = initialRiskPips * BreakevenLockR;
                    double desired = p.TradeType == TradeType.Buy
                        ? p.EntryPrice + lockPips * Symbol.PipSize
                        : p.EntryPrice - lockPips * Symbol.PipSize;
                    TightenStop(p, desired);
                }

                if (p.Pips >= initialRiskPips * TrailingStartR)
                {
                    double trailPips = initialRiskPips * TrailingDistanceR;
                    double desired = p.TradeType == TradeType.Buy
                        ? Symbol.Bid - trailPips * Symbol.PipSize
                        : Symbol.Ask + trailPips * Symbol.PipSize;
                    TightenStop(p, desired);
                }
            }
        }

        private void TightenStop(Position p, double desired)
        {
            double minDistancePips = Symbol.MinDistanceType == SymbolMinDistanceType.Pips
                ? Symbol.MinStopLossDistance
                : (p.EntryPrice * (Symbol.MinStopLossDistance / 100.0)) / Symbol.PipSize;
            double safety = Math.Max(1.0, minDistancePips) * Symbol.PipSize;

            if (p.TradeType == TradeType.Buy)
            {
                desired = Math.Min(desired, Symbol.Bid - safety);
                if (p.StopLoss.HasValue && desired <= p.StopLoss.Value + Symbol.TickSize)
                    return;
            }
            else
            {
                desired = Math.Max(desired, Symbol.Ask + safety);
                if (p.StopLoss.HasValue && desired >= p.StopLoss.Value - Symbol.TickSize)
                    return;
            }

            var result = p.ModifyStopLossPrice(desired);
            if (!result.IsSuccessful)
                Debug("SL modify failed: " + result.Error);
        }

        private bool HasAnyXauExposure()
        {
            foreach (var p in Positions)
                if (string.Equals(p.SymbolName, SymbolName, StringComparison.OrdinalIgnoreCase))
                    return true;
            foreach (var o in PendingOrders)
                if (string.Equals(o.SymbolName, SymbolName, StringComparison.OrdinalIgnoreCase))
                    return true;
            return false;
        }

        private bool RiskLimitsAllowEntry(out string reason)
        {
            reason = string.Empty;
            double dailyLoss = PercentLoss(_dayStartEquity, Account.Equity);
            double weeklyLoss = PercentLoss(_weekStartEquity, Account.Equity);
            double peakDd = PercentLoss(_peakEquity, Account.Equity);

            if (dailyLoss >= MaxDailyLossPercent) { reason = "daily loss circuit"; return false; }
            if (weeklyLoss >= MaxWeeklyLossPercent) { reason = "weekly loss circuit"; return false; }
            if (peakDd >= MaxPeakDrawdownPercent) { reason = "peak drawdown circuit"; return false; }
            if (_consecutiveLosses >= MaxConsecutiveLosses) { reason = "consecutive-loss circuit"; return false; }
            if (_lastTradeCloseUtc != DateTime.MinValue && Server.Time < _lastTradeCloseUtc.AddMinutes(CooldownM15Bars * 15.0))
            { reason = "cooldown"; return false; }
            return true;
        }

        private bool CheckEmergencyCircuit()
        {
            double peakDd = PercentLoss(_peakEquity, Account.Equity);
            if (peakDd < MaxPeakDrawdownPercent)
                return _emergencyLock;

            if (!_emergencyLock)
            {
                _emergencyLock = true;
                Print("AHP EMERGENCY LOCK | Peak equity DD={0:F2}% >= {1:F2}%", peakDd, MaxPeakDrawdownPercent);
                foreach (var p in Positions.FindAll(BotLabel, SymbolName))
                    ClosePosition(p);
            }
            return true;
        }

        private void RefreshRiskState()
        {
            DateTime ny = _session == null ? Server.Time : _session.NewYorkTime(Server.Time);
            DateTime day = ny.Date;
            DateTime week = StartOfWeek(day);

            if (_dayKey != day)
            {
                _dayKey = day;
                _dayStartEquity = Account.Equity;
                _consecutiveLosses = 0;
                SaveRiskState();
            }
            if (_weekKey != week)
            {
                _weekKey = week;
                _weekStartEquity = Account.Equity;
                SaveRiskState();
            }
            if (Account.Equity > _peakEquity)
            {
                _peakEquity = Account.Equity;
                SaveRiskState();
            }
        }

        private void OnPositionClosed(PositionClosedEventArgs args)
        {
            var p = args.Position;
            if (!string.Equals(p.SymbolName, SymbolName, StringComparison.OrdinalIgnoreCase) || p.Label != BotLabel)
                return;

            _lastTradeCloseUtc = Server.Time;
            if (p.NetProfit < 0)
                _consecutiveLosses++;
            else if (p.NetProfit > 0)
                _consecutiveLosses = 0;
            SaveRiskState();

            Print("AHP CLOSE | PID={0} | Net={1:F2} | Pips={2:F1} | ConsecutiveLosses={3}", p.Id, p.NetProfit, p.Pips, _consecutiveLosses);
        }

        private HashSet<string> LoadPatternRegistry()
        {
            var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            _usedPatternOrder = new List<string>();
            string raw = LocalStorage.GetString("Used Pattern IDs", LocalStorageScope.Type);
            if (!string.IsNullOrWhiteSpace(raw))
            {
                foreach (var s in raw.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    string id = s.Trim();
                    if (id.Length == 0 || !result.Add(id))
                        continue;
                    _usedPatternOrder.Add(id);
                    if (_usedPatternOrder.Count >= 120)
                        break;
                }
            }
            return result;
        }

        private void ClaimPattern(string id)
        {
            if (_usedPatternIds.Add(id))
            {
                _usedPatternOrder.RemoveAll(x => string.Equals(x, id, StringComparison.OrdinalIgnoreCase));
                _usedPatternOrder.Insert(0, id);
                if (_usedPatternOrder.Count > 120)
                    _usedPatternOrder.RemoveRange(120, _usedPatternOrder.Count - 120);
            }

            LocalStorage.SetString("Used Pattern IDs", string.Join(",", _usedPatternOrder), LocalStorageScope.Type);
            LocalStorage.Flush(LocalStorageScope.Type);
        }

        private void LoadRiskState()
        {
            DateTime ny = _session.NewYorkTime(Server.Time);
            _dayKey = ReadDate("Risk Day", ny.Date);
            _weekKey = ReadDate("Risk Week", StartOfWeek(ny.Date));
            _dayStartEquity = ReadDouble("Day Start Equity", Account.Equity);
            _weekStartEquity = ReadDouble("Week Start Equity", Account.Equity);
            _peakEquity = Math.Max(Account.Equity, ReadDouble("Peak Equity", Account.Equity));
            _consecutiveLosses = (int)ReadDouble("Consecutive Losses", 0);
            _lastTradeCloseUtc = ReadDateTime("Last Trade Close", DateTime.MinValue);
            RefreshRiskState();
        }

        private void SaveRiskState()
        {
            Set("Risk Day", _dayKey.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
            Set("Risk Week", _weekKey.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
            Set("Day Start Equity", _dayStartEquity.ToString("R", CultureInfo.InvariantCulture));
            Set("Week Start Equity", _weekStartEquity.ToString("R", CultureInfo.InvariantCulture));
            Set("Peak Equity", _peakEquity.ToString("R", CultureInfo.InvariantCulture));
            Set("Consecutive Losses", _consecutiveLosses.ToString(CultureInfo.InvariantCulture));
            Set("Last Trade Close", _lastTradeCloseUtc == DateTime.MinValue ? "" : _lastTradeCloseUtc.ToString("O", CultureInfo.InvariantCulture));
            LocalStorage.Flush(LocalStorageScope.Type);
        }

        private void Set(string key, string value)
        {
            LocalStorage.SetString(key, value ?? string.Empty, LocalStorageScope.Type);
        }

        private double ReadDouble(string key, double fallback)
        {
            double value;
            return double.TryParse(LocalStorage.GetString(key, LocalStorageScope.Type), NumberStyles.Float, CultureInfo.InvariantCulture, out value) ? value : fallback;
        }

        private DateTime ReadDate(string key, DateTime fallback)
        {
            DateTime value;
            return DateTime.TryParseExact(LocalStorage.GetString(key, LocalStorageScope.Type), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out value) ? value.Date : fallback.Date;
        }

        private DateTime ReadDateTime(string key, DateTime fallback)
        {
            DateTime value;
            return DateTime.TryParse(LocalStorage.GetString(key, LocalStorageScope.Type), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out value) ? value : fallback;
        }

        private static DateTime StartOfWeek(DateTime date)
        {
            int diff = (7 + ((int)date.DayOfWeek - (int)DayOfWeek.Monday)) % 7;
            return date.AddDays(-diff).Date;
        }

        private static double PercentLoss(double reference, double current)
        {
            if (reference <= 0 || current >= reference)
                return 0;
            return (reference - current) / reference * 100.0;
        }

        private bool IsGoldSymbol(string symbolName)
        {
            string n = NormalizeSymbol(symbolName);
            foreach (string alias in (GoldSymbolAliases ?? "XAUUSD,GOLD").Split(','))
            {
                string a = NormalizeSymbol(alias);
                if (!string.IsNullOrEmpty(a) && (n == a || n.StartsWith(a, StringComparison.OrdinalIgnoreCase) || n.Contains(a)))
                    return true;
            }
            return false;
        }

        private static string NormalizeSymbol(string value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;
            return new string(value.Where(char.IsLetterOrDigit).ToArray()).ToUpperInvariant();
        }

        private void EnsureHistory(Bars bars, int desired)
        {
            int attempts = 0;
            while (bars != null && bars.Count < desired && attempts++ < 8)
            {
                int loaded = bars.LoadMoreHistory();
                if (loaded <= 0)
                    break;
            }
        }

        private double ParseInitialRiskPips(string comment)
        {
            if (string.IsNullOrWhiteSpace(comment))
                return 0;
            foreach (string part in comment.Split(';'))
            {
                if (!part.StartsWith("R=", StringComparison.OrdinalIgnoreCase))
                    continue;
                double value;
                if (double.TryParse(part.Substring(2), NumberStyles.Float, CultureInfo.InvariantCulture, out value))
                    return value;
            }
            return 0;
        }

        private void Debug(string message)
        {
            if (DebugLogging)
                Print("AHP DEBUG | " + message);
        }
    }
}
